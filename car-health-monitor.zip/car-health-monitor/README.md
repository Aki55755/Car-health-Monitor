# 🚗 Smart Car Health Monitor System

A browser-based IoT-inspired vehicle health monitoring application built with HTML, CSS, and vanilla JavaScript.

---

## 📁 Project Structure

```
car-health-monitor/
├── index.html          → Landing page
├── login.html          → User login
├── register.html       → User registration + car setup
├── dashboard.html      → Live monitoring dashboard
├── reports.html        → Full health report & charts
│
├── css/
│   └── style.css       → All styles (dark industrial theme)
│
├── js/
│   ├── auth.js         → Register / Login / Session management
│   ├── sensors.js      → Simulated sensor engine (temp, fuel, pressure, voltage)
│   ├── predictions.js  → Predictive maintenance rules
│   ├── charts.js       → Chart.js chart definitions
│   └── dashboard.js    → Dashboard controller (wires everything together)
│
└── README.md
```

---

## 🚀 How to Run

1. Download / clone the project folder
2. Open `index.html` in any modern browser (Chrome, Firefox, Edge)
3. Click **Get Started** → fill in the registration form
4. You'll be redirected to the live dashboard automatically

> ✅ **No server required.** Everything runs in the browser using LocalStorage.

---

## 🔑 Features

| Feature | Description |
|---|---|
| **User Auth** | Register / Login with LocalStorage persistence |
| **Car Profile** | Store car model, purchase date, initial odometer |
| **Odometer Simulation** | Manual + automatic driving simulation |
| **Engine Temperature** | Simulated sensor with overheating detection |
| **Fuel Level** | Decreases with driving, refuel button available |
| **Tyre Pressure** | All 4 wheels tracked (FL, FR, RL, RR) |
| **Battery Voltage** | Real-time voltage monitoring |
| **Oil Life** | Calculated from km driven (5,000 km interval) |
| **Tyre Wear** | Cumulative wear % over 40,000 km tyre life |
| **Battery Health** | Age-based degradation (3-year lifespan) |
| **Next Service** | Countdown to next 10,000 km service |
| **Alert System** | Warning banners for critical conditions |
| **Repair Suggestions** | Prioritised list of maintenance actions |
| **Overall Health Score** | Composite 0–100 health index |
| **Temperature Chart** | Rolling 20-reading trend chart |
| **Distance Chart** | Bar chart of last 12 drive events |
| **Radar Chart** | Component health radar (Reports page) |
| **Full Reports** | Maintenance schedule, vehicle info, driving log |

---

## 🧮 Prediction Rules

| Component | Rule |
|---|---|
| Full Service | Every **10,000 km** |
| Oil Change | Every **5,000 km** |
| Tyre Replacement | After **40,000 km** total |
| Battery Health | Degrades over **3 years** from purchase date |
| Air Filter | Every **15,000 km** |
| Brakes | Every **25,000 km** |
| Spark Plugs | Every **30,000 km** |

---

## 🎨 Design

- Dark industrial / precision instrument theme
- Color coding: 🟢 Good | 🟡 Warning | 🔴 Critical
- Responsive — works on mobile and desktop
- Fonts: Rajdhani (display), Space Mono (numbers), Outfit (body)

---

## 🛠 Tech Stack

- **HTML5** — semantic structure
- **CSS3** — custom properties, grid, flexbox, animations
- **Vanilla JavaScript** — no frameworks
- **LocalStorage** — persistent data storage
- **Chart.js v4** — data visualisations (CDN)

---

*Built as a front-end demonstration of IoT-inspired predictive maintenance concepts.*
