// Initialize EmailJS

(function(){

emailjs.init("YOUR_PUBLIC_KEY");

})();

function sendEmailAlert(message){

let carData = JSON.parse(localStorage.getItem("carData"))

emailjs.send("service_id","template_id",{

to_email: carData.email,
message: message

})
.then(function(){

console.log("Email notification sent")

})
.catch(function(error){

console.log("Email failed", error)

})

}
function sendBrowserNotification(message){

if(Notification.permission === "granted"){

new Notification("Car Health Alert",{
body: message
})

}

}
