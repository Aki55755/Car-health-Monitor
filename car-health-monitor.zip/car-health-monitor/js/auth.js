function register(){

let name = document.getElementById("name").value
let email = document.getElementById("email").value
let password = document.getElementById("password").value
let car = document.getElementById("car").value

let user = {
name:name,
email:email,
password:password,
car:car
}

localStorage.setItem("user", JSON.stringify(user))

alert("Registration Successful")

window.location="login.html"
}

function login(){

let email=document.getElementById("email").value
let password=document.getElementById("password").value

let user=JSON.parse(localStorage.getItem("user"))

if(email===user.email && password===user.password){

alert("Login Successful")

window.location="dashboard.html"

}else{

alert("Invalid Login")

}

}