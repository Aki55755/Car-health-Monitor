/**
 * auth.js — Authentication: Register & Login
 * Uses LocalStorage to store user accounts
 */

/* ─────────────────────────────────────────────
   UTILITY HELPERS
───────────────────────────────────────────── */

/** Show an alert box above the form */
function showAlert(type, msg) {
  const existing = document.getElementById('auth-alert');
  if (existing) existing.remove();

  const icons = { error: '⚠', success: '✓', warning: '⚡' };
  const div = document.createElement('div');
  div.id = 'auth-alert';
  div.className = `alert alert-${type}`;
  div.innerHTML = `<span>${icons[type] || '•'}</span> ${msg}`;

  const form = document.querySelector('.auth-card form') ||
                document.querySelector('.auth-card');
  form.insertAdjacentElement('afterbegin', div);

  // Auto-remove after 5 s
  setTimeout(() => div.remove(), 5000);
}

/** Retrieve all accounts */
function getAccounts() {
  return JSON.parse(localStorage.getItem('chm_accounts') || '[]');
}

/** Persist all accounts */
function saveAccounts(accounts) {
  localStorage.setItem('chm_accounts', JSON.stringify(accounts));
}

/** Find an account by email */
function findAccount(email) {
  return getAccounts().find(a => a.email.toLowerCase() === email.toLowerCase());
}

/** Mark a user as logged-in */
function setSession(email) {
  localStorage.setItem('chm_session', email);
}

/** Return currently logged-in email or null */
function getSession() {
  return localStorage.getItem('chm_session');
}

/** Log out */
function clearSession() {
  localStorage.removeItem('chm_session');
}

/** Redirect to dashboard if already logged in */
function requireGuest() {
  if (getSession()) window.location.href = 'dashboard.html';
}

/** Redirect to login if NOT logged in */
function requireAuth() {
  if (!getSession()) window.location.href = 'login.html';
}

/* ─────────────────────────────────────────────
   REGISTER LOGIC
───────────────────────────────────────────── */
function initRegister() {
  requireGuest();
  const form = document.getElementById('register-form');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    clearErrors();

    const name         = val('reg-name');
    const email        = val('reg-email');
    const password     = val('reg-password');
    const carModel     = val('reg-car-model');
    const purchaseDate = val('reg-purchase-date');
    const odometer     = parseFloat(val('reg-odometer')) || 0;

    let valid = true;

    if (!name)         { showError('reg-name',          'Name is required');          valid = false; }
    if (!email)        { showError('reg-email',         'Email is required');         valid = false; }
    if (!isValidEmail(email)) { showError('reg-email',  'Enter a valid email');       valid = false; }
    if (password.length < 6){ showError('reg-password', 'Min. 6 characters');         valid = false; }
    if (!carModel)     { showError('reg-car-model',     'Car model is required');     valid = false; }
    if (!purchaseDate) { showError('reg-purchase-date', 'Purchase date is required'); valid = false; }
    if (odometer < 0)  { showError('reg-odometer',      'Must be 0 or more');         valid = false; }

    if (!valid) return;

    // Duplicate email check
    if (findAccount(email)) {
      showAlert('error', 'An account with that email already exists.');
      return;
    }

    // Build user object
    const user = {
      name, email, password,
      carModel, purchaseDate,
      initialOdometer: odometer,
      currentOdometer: odometer,
      createdAt: new Date().toISOString(),
      // Driving log: [{date, km}]
      drivingLog: [],
      // Simulated sensor values (will be updated in dashboard)
      lastSensorUpdate: null
    };

    // Save
    const accounts = getAccounts();
    accounts.push(user);
    saveAccounts(accounts);

    setSession(email);
    showAlert('success', 'Account created! Redirecting…');
    setTimeout(() => window.location.href = 'dashboard.html', 1000);
  });
}

/* ─────────────────────────────────────────────
   LOGIN LOGIC
───────────────────────────────────────────── */
function initLogin() {
  requireGuest();
  const form = document.getElementById('login-form');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    clearErrors();

    const email    = val('login-email');
    const password = val('login-password');
    let valid = true;

    if (!email)    { showError('login-email',    'Email is required');    valid = false; }
    if (!password) { showError('login-password', 'Password is required'); valid = false; }
    if (!valid) return;

    const account = findAccount(email);
    if (!account || account.password !== password) {
      showAlert('error', 'Invalid email or password.');
      return;
    }

    setSession(email);
    showAlert('success', 'Login successful! Redirecting…');
    setTimeout(() => window.location.href = 'dashboard.html', 800);
  });
}

/* ─────────────────────────────────────────────
   FIELD HELPERS
───────────────────────────────────────────── */
function val(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
}
function isValidEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

function showError(fieldId, msg) {
  const field = document.getElementById(fieldId);
  if (field) field.classList.add('error');
  const err = document.getElementById(fieldId + '-err');
  if (err) { err.textContent = msg; err.classList.add('show'); }
}

function clearErrors() {
  document.querySelectorAll('.form-input').forEach(el => el.classList.remove('error'));
  document.querySelectorAll('.form-error').forEach(el => {
    el.textContent = ''; el.classList.remove('show');
  });
}

/* ─────────────────────────────────────────────
   LOGOUT
───────────────────────────────────────────── */
function logout() {
  clearSession();
  window.location.href = 'login.html';
}
