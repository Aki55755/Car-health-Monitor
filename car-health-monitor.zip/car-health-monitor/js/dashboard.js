let distance = parseInt(localStorage.getItem("distance")) || 0

distance += 25

localStorage.setItem("distance", distance)

document.getElementById("distance").innerText =
"Total Distance: " + distance + " km"


let purchaseDate = JSON.parse(localStorage.getItem("carData")).purchaseDate

let nextService = predictNextService(distance)

let oilLife = predictOilLife(distance)

let tireWear = calculateTireWear(distance)

let batteryHealth = calculateBatteryHealth(purchaseDate)


document.getElementById("service").innerText =
"Next Service in " + nextService + " km"

document.getElementById("oil").innerText =
"Oil Change in " + oilLife + " km"

document.getElementById("tire").innerText =
"Tire Wear: " + tireWear + "%"

document.getElementById("battery").innerText =
"Battery Health: " + batteryHealth + "%"

let repairs = generateRepairSuggestions(
distance,
95,
batteryHealth,
tireWear
)

document.getElementById("repairs").innerHTML =
repairs.join("<br>")

if(oilLife < 500){

let message = "Oil change required soon"

sendEmailAlert(message)

sendBrowserNotification(message)

}

if(tireWear > 80){

let message = "Tire replacement recommended"

sendEmailAlert(message)

sendBrowserNotification(message)

}

if(engineTemp > 100){

let message = "Engine overheating detected"

sendEmailAlert(message)

sendBrowserNotification(message)

}