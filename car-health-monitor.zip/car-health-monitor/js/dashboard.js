/**
 * dashboard.js — Dashboard Controller
 * Wires all sensors, predictions, and charts together.
 * Auto-simulates driving every few seconds.
 */

/* ─────────────────────────────────────────────
   STATE
───────────────────────────────────────────── */
let autoSimInterval = null;
let uiRefreshInterval = null;
let isAutoSimActive = false;
let selectedKmPerTick = 10; // controlled by slider

/* ─────────────────────────────────────────────
   INIT
───────────────────────────────────────────── */
function initDashboard() {
  requireAuth();

  const user = getCurrentUser();
  if (!user) { logout(); return; }

  // Populate nav user info
  setNavUser(user);

  // Render static car strip
  renderCarStrip(user);

  // Initial render
  refreshDashboard();

  // Auto-simulate: every 8 seconds add some km
  startAutoSim();

  // UI refresh: every 3 seconds (sensor values update more often)
  uiRefreshInterval = setInterval(refreshDashboard, 3000);

  // Slider listener
  const slider = document.getElementById('sim-km-slider');
  const label  = document.getElementById('sim-km-label');
  if (slider) {
    slider.addEventListener('input', () => {
      selectedKmPerTick = parseInt(slider.value);
      if (label) label.textContent = selectedKmPerTick + ' km';
    });
  }

  // Manual drive button
  const driveBtn = document.getElementById('btn-manual-drive');
  if (driveBtn) {
    driveBtn.addEventListener('click', () => {
      simulateDriveTick(selectedKmPerTick);
      refreshDashboard();
    });
  }

  // Toggle auto-sim
  const toggleBtn = document.getElementById('btn-toggle-sim');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', toggleAutoSim);
  }

  // Refuel button
  const refuelBtn = document.getElementById('btn-refuel');
  if (refuelBtn) { refuelBtn.addEventListener('click', () => { refuel(); refreshDashboard(); }); }

  // Inflate button
  const inflateBtn = document.getElementById('btn-inflate');
  if (inflateBtn) { inflateBtn.addEventListener('click', () => { inflateTyres(); refreshDashboard(); }); }
}

/* ─────────────────────────────────────────────
   AUTO SIMULATION
───────────────────────────────────────────── */
function startAutoSim() {
  isAutoSimActive = true;
  updateSimBtn();
  autoSimInterval = setInterval(() => {
    const km = Math.floor(Math.random() * selectedKmPerTick * 0.5 + selectedKmPerTick * 0.1);
    simulateDriveTick(km > 0 ? km : 1);
  }, 8000);
}

function stopAutoSim() {
  isAutoSimActive = false;
  updateSimBtn();
  clearInterval(autoSimInterval);
}

function toggleAutoSim() {
  if (isAutoSimActive) stopAutoSim();
  else startAutoSim();
}

function updateSimBtn() {
  const btn = document.getElementById('btn-toggle-sim');
  if (!btn) return;
  if (isAutoSimActive) {
    btn.textContent = '⏸ Pause Simulation';
    btn.className = 'btn btn-secondary';
  } else {
    btn.textContent = '▶ Resume Simulation';
    btn.className = 'btn btn-primary';
  }
}

/* ─────────────────────────────────────────────
   ONE DRIVE TICK
───────────────────────────────────────────── */
function simulateDriveTick(km) {
  const user = driveKm(km);           // advance odometer
  const sensors = simulateSensorTick(km); // update sensors
  if (sensors) pushTempReading(sensors.engineTemp); // temp history
  return { user, sensors };
}

/* ─────────────────────────────────────────────
   REFRESH ALL DASHBOARD UI
───────────────────────────────────────────── */
function refreshDashboard() {
  const user    = getCurrentUser();
  const sensors = getSensors();
  if (!user || !sensors) return;

  updateStatCards(user, sensors);
  renderAlerts(user, sensors);
  renderHealthCards(user, sensors);
  renderSuggestions(user, sensors);
  updateTempChart(sensors.engineTemp);
  updateDistanceChart(user.drivingLog);
}

/* ─────────────────────────────────────────────
   NAV USER
───────────────────────────────────────────── */
function setNavUser(user) {
  const el = document.getElementById('nav-user-name');
  if (el) el.textContent = user.name;
  const av = document.getElementById('nav-avatar');
  if (av) av.textContent = user.name.charAt(0).toUpperCase();
}

/* ─────────────────────────────────────────────
   CAR INFO STRIP
───────────────────────────────────────────── */
function renderCarStrip(user) {
  setText('car-strip-model', user.carModel);
  setText('car-strip-since', new Date(user.purchaseDate).toLocaleDateString([], { year:'numeric', month:'short', day:'numeric' }));
  setText('car-strip-init-odo', user.initialOdometer.toLocaleString() + ' km');
}

/* ─────────────────────────────────────────────
   STAT CARDS
───────────────────────────────────────────── */
function updateStatCards(user, sensors) {
  const driven = getTotalKm(user);

  setText('stat-distance',    Math.round(user.currentOdometer).toLocaleString());
  setText('stat-driven-total', Math.round(driven).toLocaleString() + ' km total');

  const tStat = getTempStatus(sensors.engineTemp);
  setText('stat-temp',         sensors.engineTemp.toFixed(1));
  setText('stat-temp-status',  tStat.label);

  const oil = getOilHealth(user);
  setText('stat-oil',          oil.remaining);
  setText('stat-oil-detail',   oil.kmLeft.toLocaleString() + ' km to change');
  updateBar('bar-oil', oil.remaining,
    oil.remaining <= 10 ? 'fill-red' : oil.remaining <= 25 ? 'fill-orange' : 'fill-green');

  const fStat = getFuelStatus(sensors.fuelLevel);
  setText('stat-fuel',         sensors.fuelLevel.toFixed(0));
  updateBar('bar-fuel', sensors.fuelLevel,
    fStat.color === 'red' ? 'fill-red' : fStat.color === 'orange' ? 'fill-orange' :
    fStat.color === 'yellow' ? 'fill-yellow' : 'fill-green');

  // Battery health card
  const bat = getBatteryHealth(user);
  setText('stat-battery',      bat.healthPct);
  setText('stat-battery-detail', bat.ageYears.toFixed(1) + ' yrs old');
  updateBar('bar-battery', bat.healthPct,
    bat.healthPct <= 20 ? 'fill-red' : bat.healthPct <= 40 ? 'fill-orange' : 'fill-green');

  // Overall score
  const score = getOverallHealthScore(user, sensors);
  setText('stat-score', score);
  const scoreCard = document.getElementById('card-score');
  if (scoreCard) {
    scoreCard.className = 'stat-card ' +
      (score >= 70 ? 'green' : score >= 40 ? 'yellow' : 'red');
  }
}

/* ─────────────────────────────────────────────
   ALERT BANNERS
───────────────────────────────────────────── */
function renderAlerts(user, sensors) {
  const container = document.getElementById('alerts-container');
  if (!container) return;

  const alerts = getDashboardAlerts(user, sensors);
  container.innerHTML = '';

  alerts.forEach(a => {
    const div = document.createElement('div');
    div.className = `alert-banner ${a.type}`;
    div.textContent = a.msg;
    container.appendChild(div);
  });
}

/* ─────────────────────────────────────────────
   HEALTH DETAIL CARDS
───────────────────────────────────────────── */
function renderHealthCards(user, sensors) {
  // Engine temp card
  const tStat = getTempStatus(sensors.engineTemp);
  setText('hc-temp-val',    sensors.engineTemp.toFixed(1) + '°C');
  setText('hc-temp-status', tStat.label);
  updateBar('hc-temp-bar', Math.min(100, ((sensors.engineTemp - 70) / 50) * 100),
    tStat.color === 'red' ? 'fill-red' : tStat.color === 'orange' ? 'fill-orange' : 'fill-green');

  // Battery voltage
  const bvStat = getBatteryVoltageStatus(sensors.batteryVoltage);
  setText('hc-bvolt-val', sensors.batteryVoltage.toFixed(2) + ' V');
  setText('hc-bvolt-status', bvStat.label);
  const bvPct = ((sensors.batteryVoltage - 11) / 2.5) * 100;
  updateBar('hc-bvolt-bar', bvPct,
    bvStat.color === 'red' ? 'fill-red' : bvStat.color === 'orange' ? 'fill-orange' : 'fill-green');

  // Tyre pressure (average)
  const pressures = [sensors.tyrePressureFL, sensors.tyrePressureFR, sensors.tyrePressureRL, sensors.tyrePressureRR];
  const avgP = pressures.reduce((a, b) => a + b, 0) / 4;
  const pStat = getPressureStatus(avgP);
  setText('hc-tyre-fl', sensors.tyrePressureFL.toFixed(1));
  setText('hc-tyre-fr', sensors.tyrePressureFR.toFixed(1));
  setText('hc-tyre-rl', sensors.tyrePressureRL.toFixed(1));
  setText('hc-tyre-rr', sensors.tyrePressureRR.toFixed(1));
  setText('hc-tyre-status', pStat.label);

  // Tyre wear (health based on km)
  const tyre = getTyreHealth(user);
  setText('hc-tyre-wear', tyre.wearPct + '%');
  updateBar('hc-tyre-wear-bar', tyre.wearPct,
    tyre.wearPct >= 85 ? 'fill-red' : tyre.wearPct >= 65 ? 'fill-orange' : 'fill-green');

  // Next service
  const srv = getNextService(user);
  setText('hc-service-km', srv.kmLeft.toLocaleString() + ' km');
  setText('hc-service-at',  'Due @ ' + Math.round(srv.nextAt).toLocaleString() + ' km');
  updateBar('hc-service-bar', 100 - srv.pct,
    srv.status === 'critical' ? 'fill-red' : srv.status === 'warning' ? 'fill-orange' : 'fill-accent');
}

/* ─────────────────────────────────────────────
   REPAIR SUGGESTIONS LIST
───────────────────────────────────────────── */
function renderSuggestions(user, sensors) {
  const container = document.getElementById('suggestions-list');
  if (!container) return;

  const suggestions = getRepairSuggestions(user, sensors);
  const priorityClass = {
    critical: 'p-critical', warning: 'p-high', high: 'p-high',
    medium: 'p-medium', low: 'p-low'
  };
  const iconBg = {
    critical: 'hc-red', warning: 'hc-orange', high: 'hc-orange',
    medium: 'hc-yellow', low: 'hc-green'
  };

  container.innerHTML = suggestions.map(s => `
    <div class="suggestion-item">
      <div class="sug-icon ${iconBg[s.priority] || 'hc-accent'}">${s.icon}</div>
      <div class="sug-content">
        <div class="sug-title">${s.title}</div>
        <div class="sug-detail">${s.detail}</div>
      </div>
      <span class="sug-priority ${priorityClass[s.priority] || 'p-low'}">${s.priority}</span>
    </div>
  `).join('');
}

/* ─────────────────────────────────────────────
   DOM HELPERS
───────────────────────────────────────────── */
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function updateBar(id, pct, fillClass) {
  const fill = document.getElementById(id);
  if (!fill) return;
  fill.style.width = Math.max(0, Math.min(100, pct)) + '%';
  // Remove all fill classes then add the new one
  fill.classList.remove('fill-accent','fill-green','fill-yellow','fill-orange','fill-red');
  if (fillClass) fill.classList.add(fillClass);
}
