const ctx=document.getElementById("chart")

new Chart(ctx,{
type:"line",
data:{
labels:["1","2","3","4","5","6"],
datasets:[{
label:"Engine Temperature",
data:[80,85,90,92,88,95],
borderColor:"#38bdf8",
fill:false,
tension:0.4
}]
},
options:{
animation:{
duration:1500
}
}
})