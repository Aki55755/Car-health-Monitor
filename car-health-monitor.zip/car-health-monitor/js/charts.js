/**
 * charts.js — Chart.js Chart Definitions
 * Creates and updates the temperature trend and distance usage charts.
 */

/* ─────────────────────────────────────────────
   THEME
───────────────────────────────────────────── */
const CHART_THEME = {
  accent:  '#00d4ff',
  green:   '#00e676',
  orange:  '#ff9800',
  red:     '#ff3d3d',
  yellow:  '#ffea00',
  grid:    'rgba(255,255,255,0.05)',
  text:    '#7a8fa8',
  bg:      'transparent'
};

Chart.defaults.color      = CHART_THEME.text;
Chart.defaults.font.family = "'Outfit', sans-serif";

/* ─────────────────────────────────────────────
   TEMPERATURE HISTORY (line chart)
───────────────────────────────────────────── */
let tempChartInstance = null;
// Rolling buffer of last N temperature readings
const MAX_TEMP_POINTS = 20;
let tempHistory = [];

function initTempHistory() {
  const email = getSession();
  if (!email) return;
  const raw = localStorage.getItem(`chm_tempHistory_${email}`);
  tempHistory = raw ? JSON.parse(raw) : [];
}

function pushTempReading(val) {
  const email = getSession();
  if (!email) return;
  tempHistory.push({ t: new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'}), v: +val.toFixed(1) });
  if (tempHistory.length > MAX_TEMP_POINTS) tempHistory.shift();
  localStorage.setItem(`chm_tempHistory_${email}`, JSON.stringify(tempHistory));
}

function createTempChart(canvasId) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (tempChartInstance) { tempChartInstance.destroy(); tempChartInstance = null; }

  initTempHistory();

  const labels = tempHistory.map(d => d.t);
  const data   = tempHistory.map(d => d.v);

  tempChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Engine Temp (°C)',
        data,
        borderColor: CHART_THEME.orange,
        backgroundColor: 'rgba(255,152,0,0.08)',
        borderWidth: 2,
        pointRadius: 3,
        pointBackgroundColor: CHART_THEME.orange,
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 400 },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#111621',
          borderColor: '#1e2a3a',
          borderWidth: 1,
          titleColor: '#e8edf5',
          bodyColor: '#7a8fa8',
          callbacks: {
            label: ctx => `  ${ctx.parsed.y.toFixed(1)} °C`
          }
        }
      },
      scales: {
        x: {
          grid: { color: CHART_THEME.grid },
          ticks: { maxTicksLimit: 6, font: { size: 10 } }
        },
        y: {
          grid: { color: CHART_THEME.grid },
          min: 70, max: 120,
          ticks: {
            callback: v => v + '°C',
            font: { size: 10 }
          }
        }
      }
    }
  });
}

function updateTempChart(newTemp) {
  if (!tempChartInstance) return;
  pushTempReading(newTemp);

  tempChartInstance.data.labels = tempHistory.map(d => d.t);
  tempChartInstance.data.datasets[0].data = tempHistory.map(d => d.v);

  // Colour the line based on temp zone
  const color = newTemp >= 105 ? CHART_THEME.red :
                newTemp >= 95  ? CHART_THEME.orange : CHART_THEME.accent;
  tempChartInstance.data.datasets[0].borderColor = color;
  tempChartInstance.data.datasets[0].pointBackgroundColor = color;

  tempChartInstance.update('none');
}

/* ─────────────────────────────────────────────
   DISTANCE USAGE (bar chart) — last 10 log entries
───────────────────────────────────────────── */
let distChartInstance = null;

function createDistanceChart(canvasId, drivingLog) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (distChartInstance) { distChartInstance.destroy(); distChartInstance = null; }

  const log = (drivingLog || []).slice(-12);
  const labels = log.map((d, i) =>
    new Date(d.date).toLocaleDateString([], { month:'short', day:'numeric' })
  );
  const data = log.map(d => d.km);

  distChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Distance (km)',
        data,
        backgroundColor: log.map(d => 'rgba(0,212,255,0.55)'),
        borderColor: CHART_THEME.accent,
        borderWidth: 1,
        borderRadius: 4,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 500 },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#111621',
          borderColor: '#1e2a3a',
          borderWidth: 1,
          titleColor: '#e8edf5',
          bodyColor: '#7a8fa8',
          callbacks: {
            label: ctx => `  ${ctx.parsed.y} km driven`
          }
        }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 10 } } },
        y: {
          grid: { color: CHART_THEME.grid },
          ticks: { callback: v => v + ' km', font: { size: 10 } }
        }
      }
    }
  });
}

function updateDistanceChart(drivingLog) {
  if (!distChartInstance) return;
  const log = (drivingLog || []).slice(-12);
  distChartInstance.data.labels   = log.map(d =>
    new Date(d.date).toLocaleDateString([], { month:'short', day:'numeric' })
  );
  distChartInstance.data.datasets[0].data = log.map(d => d.km);
  distChartInstance.update();
}

/* ─────────────────────────────────────────────
   HEALTH RADAR CHART (reports page)
───────────────────────────────────────────── */
let radarChartInstance = null;

function createHealthRadar(canvasId, scores) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (radarChartInstance) { radarChartInstance.destroy(); radarChartInstance = null; }

  radarChartInstance = new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Oil', 'Tyres', 'Battery', 'Service', 'Air Filter', 'Brakes'],
      datasets: [{
        label: 'Health %',
        data: scores,
        backgroundColor: 'rgba(0,212,255,0.1)',
        borderColor: CHART_THEME.accent,
        pointBackgroundColor: CHART_THEME.accent,
        borderWidth: 2,
        pointRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 600 },
      plugins: { legend: { display: false } },
      scales: {
        r: {
          min: 0, max: 100,
          backgroundColor: 'transparent',
          grid:      { color: CHART_THEME.grid },
          angleLines: { color: CHART_THEME.grid },
          pointLabels: { font: { size: 11 }, color: CHART_THEME.text },
          ticks: {
            backdropColor: 'transparent',
            color: CHART_THEME.text,
            font: { size: 9 },
            stepSize: 25
          }
        }
      }
    }
  });
}

/* ─────────────────────────────────────────────
   COMPONENT HEALTH BAR CHART (reports)
───────────────────────────────────────────── */
let compBarInstance = null;

function createComponentBars(canvasId, scores) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (compBarInstance) { compBarInstance.destroy(); compBarInstance = null; }

  const colors = scores.map(s =>
    s >= 70 ? CHART_THEME.green :
    s >= 40 ? CHART_THEME.yellow : CHART_THEME.red
  );

  compBarInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Oil', 'Tyres', 'Battery', 'Service', 'Air Filter', 'Brakes', 'Spark Plugs'],
      datasets: [{
        data: scores,
        backgroundColor: colors.map(c => c + '55'),
        borderColor: colors,
        borderWidth: 1.5,
        borderRadius: 4
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#111621',
          borderColor: '#1e2a3a',
          borderWidth: 1,
          callbacks: { label: ctx => `  Health: ${ctx.parsed.x}%` }
        }
      },
      scales: {
        x: {
          max: 100,
          grid: { color: CHART_THEME.grid },
          ticks: { callback: v => v + '%', font: { size: 10 } }
        },
        y: {
          grid: { display: false },
          ticks: { font: { size: 11 } }
        }
      }
    }
  });
}
