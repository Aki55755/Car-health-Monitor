/**
 * predictions.js — Predictive Maintenance Engine
 * Rules-based system that estimates component health
 * and generates repair suggestions.
 */

/* ─────────────────────────────────────────────
   CONSTANTS  (all distances in km)
───────────────────────────────────────────── */
const RULES = {
  serviceInterval:   10000,  // Full service every 10,000 km
  oilInterval:        5000,  // Oil change every 5,000 km
  tyreTotalLife:     40000,  // Tyres last 40,000 km total
  batteryLifeYears:      3,  // Battery lifespan in years
  airFilterInterval:  15000,
  brakeInterval:      25000,
  sparkPlugInterval:  30000,
};

/* ─────────────────────────────────────────────
   GET CURRENT USER DATA
───────────────────────────────────────────── */
function getCurrentUser() {
  const email = getSession();
  if (!email) return null;
  return findAccount(email);
}

function updateUser(updatedUser) {
  const accounts = getAccounts();
  const idx = accounts.findIndex(a => a.email === updatedUser.email);
  if (idx >= 0) {
    accounts[idx] = updatedUser;
    saveAccounts(accounts);
  }
}

/* ─────────────────────────────────────────────
   DISTANCE & ODOMETER
───────────────────────────────────────────── */
function getTotalKm(user) {
  return user.currentOdometer - user.initialOdometer;
}

/** Add km to odometer + log entry */
function driveKm(km) {
  const user = getCurrentUser();
  if (!user) return;

  user.currentOdometer += km;

  // Add to driving log
  if (!user.drivingLog) user.drivingLog = [];
  user.drivingLog.push({
    date: new Date().toISOString(),
    km: km,
    odometer: user.currentOdometer
  });

  // Keep last 30 entries
  if (user.drivingLog.length > 30) user.drivingLog.shift();

  updateUser(user);
  return user;
}

/* ─────────────────────────────────────────────
   OIL LIFE
   Returns: { remaining: %, kmLeft, nextChangeAt }
───────────────────────────────────────────── */
function getOilHealth(user) {
  const driven = getTotalKm(user);
  const cycleKm = driven % RULES.oilInterval;  // km into current cycle
  const kmLeft  = RULES.oilInterval - cycleKm;
  const remaining = Math.round((kmLeft / RULES.oilInterval) * 100);

  return {
    remaining,
    kmLeft: Math.round(kmLeft),
    nextChangeAt: user.currentOdometer + kmLeft,
    status: remaining <= 10 ? 'critical' :
            remaining <= 25 ? 'warning'  : 'good'
  };
}

/* ─────────────────────────────────────────────
   TYRE WEAR
   Returns: { wearPct, kmLeft, remainingLife }
───────────────────────────────────────────── */
function getTyreHealth(user) {
  const driven   = getTotalKm(user);
  const wearKm   = driven % RULES.tyreTotalLife;   // km on current set
  const wearPct  = Math.round((wearKm / RULES.tyreTotalLife) * 100);
  const kmLeft   = RULES.tyreTotalLife - wearKm;

  return {
    wearPct,
    health: 100 - wearPct,
    kmLeft: Math.round(kmLeft),
    replaceAt: user.currentOdometer + kmLeft,
    status: wearPct >= 85 ? 'critical' :
            wearPct >= 65 ? 'warning'  : 'good'
  };
}

/* ─────────────────────────────────────────────
   BATTERY HEALTH
   Degrades based on age from purchase date
   Returns: { healthPct, ageYears, yearsLeft }
───────────────────────────────────────────── */
function getBatteryHealth(user) {
  const purchaseMs  = new Date(user.purchaseDate).getTime();
  const nowMs       = Date.now();
  const ageYears    = (nowMs - purchaseMs) / (1000 * 60 * 60 * 24 * 365.25);
  const healthPct   = Math.max(0, Math.round(
    (1 - ageYears / RULES.batteryLifeYears) * 100
  ));
  const yearsLeft   = Math.max(0, RULES.batteryLifeYears - ageYears);

  return {
    healthPct,
    ageYears: +ageYears.toFixed(2),
    yearsLeft: +yearsLeft.toFixed(1),
    replaceDate: new Date(
      purchaseMs + RULES.batteryLifeYears * 365.25 * 24 * 3600 * 1000
    ).toLocaleDateString(),
    status: healthPct <= 20 ? 'critical' :
            healthPct <= 40 ? 'warning'  : 'good'
  };
}

/* ─────────────────────────────────────────────
   NEXT SERVICE
───────────────────────────────────────────── */
function getNextService(user) {
  const driven   = getTotalKm(user);
  const cycleKm  = driven % RULES.serviceInterval;
  const kmLeft   = RULES.serviceInterval - cycleKm;
  const pct      = Math.round((kmLeft / RULES.serviceInterval) * 100);

  return {
    kmLeft:    Math.round(kmLeft),
    nextAt:    user.currentOdometer + kmLeft,
    pct,
    status:    kmLeft <= 500 ? 'critical' : kmLeft <= 1500 ? 'warning' : 'good'
  };
}

/* ─────────────────────────────────────────────
   OTHER COMPONENTS
───────────────────────────────────────────── */
function getAirFilterHealth(user) {
  const driven  = getTotalKm(user);
  const kmLeft  = RULES.airFilterInterval - (driven % RULES.airFilterInterval);
  const pct     = Math.round((kmLeft / RULES.airFilterInterval) * 100);
  return { pct, kmLeft: Math.round(kmLeft),
           status: pct <= 10 ? 'critical' : pct <= 25 ? 'warning' : 'good' };
}

function getBrakeHealth(user) {
  const driven  = getTotalKm(user);
  const kmLeft  = RULES.brakeInterval - (driven % RULES.brakeInterval);
  const health  = Math.round((kmLeft / RULES.brakeInterval) * 100);
  return { health, kmLeft: Math.round(kmLeft),
           status: health <= 15 ? 'critical' : health <= 30 ? 'warning' : 'good' };
}

function getSparkPlugHealth(user) {
  const driven  = getTotalKm(user);
  const kmLeft  = RULES.sparkPlugInterval - (driven % RULES.sparkPlugInterval);
  const pct     = Math.round((kmLeft / RULES.sparkPlugInterval) * 100);
  return { pct, kmLeft: Math.round(kmLeft),
           status: pct <= 10 ? 'critical' : pct <= 20 ? 'warning' : 'good' };
}

/* ─────────────────────────────────────────────
   REPAIR SUGGESTIONS
   Returns array of suggestion objects sorted by priority
───────────────────────────────────────────── */
function getRepairSuggestions(user, sensors) {
  const suggestions = [];
  const oil     = getOilHealth(user);
  const tyre    = getTyreHealth(user);
  const battery = getBatteryHealth(user);
  const service = getNextService(user);
  const air     = getAirFilterHealth(user);
  const brakes  = getBrakeHealth(user);
  const sparks  = getSparkPlugHealth(user);

  if (sensors && sensors.engineTemp >= 105) {
    suggestions.push({
      priority: 'critical',
      icon: '🌡️', title: 'Engine Overheating',
      detail: `Engine at ${sensors.engineTemp.toFixed(0)}°C — pull over safely and check coolant.`,
      p: 0
    });
  }

  if (service.status !== 'good') {
    suggestions.push({
      priority: service.status,
      icon: '🔧', title: 'Full Service Due',
      detail: `Next service in ${service.kmLeft.toLocaleString()} km (@ ${Math.round(service.nextAt).toLocaleString()} km).`,
      p: 1
    });
  }

  if (oil.status !== 'good') {
    suggestions.push({
      priority: oil.status,
      icon: '🛢️', title: 'Oil Change Required',
      detail: `Oil life ${oil.remaining}% — change due in ${oil.kmLeft.toLocaleString()} km.`,
      p: 2
    });
  }

  if (tyre.status !== 'good') {
    suggestions.push({
      priority: tyre.status,
      icon: '🔄', title: 'Tyre Replacement Needed',
      detail: `Tyre wear at ${tyre.wearPct}% — ${tyre.kmLeft.toLocaleString()} km remaining life.`,
      p: 3
    });
  }

  if (battery.status !== 'good') {
    suggestions.push({
      priority: battery.status,
      icon: '🔋', title: 'Battery Health Low',
      detail: `Battery health ${battery.healthPct}% — age ${battery.ageYears.toFixed(1)} yrs. Replace by ${battery.replaceDate}.`,
      p: 4
    });
  }

  if (sensors) {
    const avgPressure = (sensors.tyrePressureFL + sensors.tyrePressureFR +
                         sensors.tyrePressureRL + sensors.tyrePressureRR) / 4;
    if (avgPressure < 27) {
      suggestions.push({
        priority: avgPressure < 24 ? 'critical' : 'medium',
        icon: '🔩', title: 'Low Tyre Pressure',
        detail: `Average pressure ${avgPressure.toFixed(1)} PSI — inflate to 31-33 PSI.`,
        p: 5
      });
    }

    if (sensors.fuelLevel <= 20) {
      suggestions.push({
        priority: sensors.fuelLevel <= 10 ? 'critical' : 'high',
        icon: '⛽', title: 'Refuel Soon',
        detail: `Fuel level at ${sensors.fuelLevel.toFixed(0)}% — find a petrol station.`,
        p: 6
      });
    }

    if (sensors.batteryVoltage < 12.2) {
      suggestions.push({
        priority: sensors.batteryVoltage < 11.8 ? 'critical' : 'high',
        icon: '⚡', title: 'Low Battery Voltage',
        detail: `${sensors.batteryVoltage.toFixed(2)} V detected — check charging system.`,
        p: 7
      });
    }
  }

  if (air.status !== 'good') {
    suggestions.push({
      priority: air.status,
      icon: '💨', title: 'Air Filter Replacement',
      detail: `Air filter at ${air.pct}% — replace in ${air.kmLeft.toLocaleString()} km.`,
      p: 8
    });
  }

  if (brakes.status !== 'good') {
    suggestions.push({
      priority: brakes.status,
      icon: '🛑', title: 'Brake Inspection',
      detail: `Brake health ${brakes.health}% — inspect pads in ${brakes.kmLeft.toLocaleString()} km.`,
      p: 9
    });
  }

  if (sparks.status !== 'good') {
    suggestions.push({
      priority: sparks.status,
      icon: '⚡', title: 'Spark Plug Check',
      detail: `Spark plugs at ${sparks.pct}% — replace in ${sparks.kmLeft.toLocaleString()} km.`,
      p: 10
    });
  }

  // If all good
  if (suggestions.length === 0) {
    suggestions.push({
      priority: 'low',
      icon: '✅', title: 'All Systems Nominal',
      detail: 'Your vehicle is in excellent health. Keep it up!',
      p: 99
    });
  }

  // Sort: critical → warning → high → medium → low
  const order = { critical: 0, warning: 1, high: 2, medium: 3, low: 4 };
  suggestions.sort((a, b) => (order[a.priority] ?? 5) - (order[b.priority] ?? 5));
  return suggestions;
}

/* ─────────────────────────────────────────────
   DASHBOARD ALERTS  (warning banners)
───────────────────────────────────────────── */
function getDashboardAlerts(user, sensors) {
  const alerts = [];

  if (sensors) {
    if (sensors.engineTemp >= 105) alerts.push({ type:'danger',  msg: '🌡️ Engine temperature critical! Pull over immediately.' });
    else if (sensors.engineTemp >= 95) alerts.push({ type:'warning', msg: '🌡️ Engine temperature high — monitor closely.' });

    if (sensors.fuelLevel <= 10) alerts.push({ type:'danger',  msg: '⛽ Fuel critically low — refuel now!' });
    else if (sensors.fuelLevel <= 20) alerts.push({ type:'warning', msg: '⛽ Low fuel — refuel soon.' });

    if (sensors.batteryVoltage < 11.8) alerts.push({ type:'danger',  msg: '⚡ Battery voltage critically low!' });
    else if (sensors.batteryVoltage < 12.2) alerts.push({ type:'warning', msg: '⚡ Low battery voltage detected.' });

    const minP = Math.min(sensors.tyrePressureFL, sensors.tyrePressureFR, sensors.tyrePressureRL, sensors.tyrePressureRR);
    if (minP < 24) alerts.push({ type:'danger',  msg: '🔩 Tyre pressure dangerously low — stop safely!' });
    else if (minP < 27) alerts.push({ type:'warning', msg: '🔩 Tyre pressure below recommended range.' });
  }

  const oil = getOilHealth(user);
  if (oil.remaining <= 5)  alerts.push({ type:'danger',  msg: '🛢️ Oil change overdue!' });
  else if (oil.remaining <= 15) alerts.push({ type:'warning', msg: '🛢️ Oil change due soon.' });

  const bat = getBatteryHealth(user);
  if (bat.healthPct <= 20) alerts.push({ type:'danger',  msg: '🔋 Battery health critical — replace battery.' });

  return alerts;
}

/* ─────────────────────────────────────────────
   OVERALL HEALTH SCORE  0–100
───────────────────────────────────────────── */
function getOverallHealthScore(user, sensors) {
  const oil     = getOilHealth(user).remaining;
  const tyre    = getTyreHealth(user).health;
  const battery = getBatteryHealth(user).healthPct;
  const service = getNextService(user).pct;

  let score = (oil * 0.25) + (tyre * 0.25) + (battery * 0.25) + (service * 0.25);

  if (sensors) {
    if (sensors.engineTemp >= 105) score -= 20;
    else if (sensors.engineTemp >= 95) score -= 10;
    if (sensors.fuelLevel <= 10) score -= 5;
    if (sensors.batteryVoltage < 11.8) score -= 10;
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}
