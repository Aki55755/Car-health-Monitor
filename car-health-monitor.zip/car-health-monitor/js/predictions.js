// predictions.js
// Predictive maintenance logic for Car Health Monitor


// Predict next service (every 10000 km)
function predictNextService(distance){

let nextService = 10000 - (distance % 10000)

return nextService

}


// Predict oil change (every 5000 km)
function predictOilLife(distance){

let oilRemaining = 5000 - (distance % 5000)

return oilRemaining

}


// Calculate tire wear percentage (life ≈ 40000 km)
function calculateTireWear(distance){

let wear = (distance / 40000) * 100

if(wear > 100){
wear = 100
}

return wear.toFixed(1)

}


// Calculate battery health (life ≈ 3 years)
function calculateBatteryHealth(purchaseDate){

let purchase = new Date(purchaseDate)

let today = new Date()

let diffYears = (today - purchase) / (1000*60*60*24*365)

let health = 100 - ((diffYears / 3) * 100)

if(health < 0){
health = 0
}

return health.toFixed(1)

}


// Detect engine overheating
function checkEngineRisk(temp){

if(temp > 100){
return "⚠ Engine overheating risk"
}

return "Engine temperature normal"

}


// Generate repair suggestions
function generateRepairSuggestions(distance, temp, batteryHealth, tireWear){

let suggestions = []

if(temp > 100){
suggestions.push("Check engine cooling system")
}

if(predictOilLife(distance) < 500){
suggestions.push("Oil change required soon")
}

if(tireWear > 80){
suggestions.push("Replace tires soon")
}

if(batteryHealth < 30){
suggestions.push("Battery replacement recommended")
}

if(suggestions.length === 0){
suggestions.push("Vehicle condition good")
}

return suggestions

}