function checkAlerts(data){

let alerts=""

if(data.engineTemp > 100){
alerts+="🔥 Engine Overheating<br>"
sendNotification("Engine overheating detected")
}

if(data.fuel < 20){
alerts+="⛽ Low Fuel Level<br>"
sendNotification("Fuel level very low")
}

if(data.tire < 30){
alerts+="🛞 Tire pressure low<br>"
sendNotification("Tire pressure low")
}

document.getElementById("alerts").innerHTML=alerts

}