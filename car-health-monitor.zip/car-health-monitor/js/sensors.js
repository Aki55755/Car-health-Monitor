/**
 * sensors.js — Simulated Vehicle Sensor Engine
 * Generates realistic-looking sensor readings that
 * fluctuate over time: temperature, fuel, tyre pressure, battery voltage.
 */

/* ─────────────────────────────────────────────
   DEFAULTS
───────────────────────────────────────────── */
const SENSOR_DEFAULTS = {
  engineTemp:    88,   // °C
  fuelLevel:     85,   // %
  tyrePressureFL: 32,  // PSI
  tyrePressureFR: 32,
  tyrePressureRL: 31,
  tyrePressureRR: 31,
  batteryVoltage: 12.6 // V
};

/* ─────────────────────────────────────────────
   GET / INIT SENSORS FOR CURRENT USER
───────────────────────────────────────────── */
function getSensors() {
  const email = getSession();
  if (!email) return null;

  const key = `chm_sensors_${email}`;
  const raw = localStorage.getItem(key);
  if (raw) return JSON.parse(raw);

  // First-time: seed from defaults
  const s = {
    ...SENSOR_DEFAULTS,
    updatedAt: new Date().toISOString()
  };
  localStorage.setItem(key, JSON.stringify(s));
  return s;
}

function saveSensors(sensors) {
  const email = getSession();
  if (!email) return;
  sensors.updatedAt = new Date().toISOString();
  localStorage.setItem(`chm_sensors_${email}`, JSON.stringify(sensors));
}

/* ─────────────────────────────────────────────
   SIMULATE ONE TICK (called by dashboard interval)
   km — kilometres driven in this tick
───────────────────────────────────────────── */
function simulateSensorTick(km) {
  const s = getSensors();
  if (!s) return null;

  const r = (min, max) => Math.random() * (max - min) + min;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  // Engine temperature: rises when driving, cools slowly
  if (km > 0) {
    s.engineTemp += r(0.5, 1.5) * km;   // heat up
  } else {
    s.engineTemp -= r(0.2, 0.6);        // cool down
  }
  s.engineTemp = clamp(s.engineTemp + r(-1, 1), 75, 115);

  // Fuel: decreases with km (avg 12 km/L → ~8% per 10 km)
  if (km > 0) {
    s.fuelLevel -= (km / 12) * r(0.8, 1.2);
  }
  s.fuelLevel = clamp(s.fuelLevel, 0, 100);

  // Tyre pressure: very slowly drifts down with km + random noise
  ['FL', 'FR', 'RL', 'RR'].forEach(pos => {
    const key = `tyrePressure${pos}`;
    s[key] += r(-0.15, 0.05);
    if (km > 0) s[key] -= km * 0.002;
    s[key] = clamp(s[key], 22, 35);
  });

  // Battery voltage: slight noise
  s.batteryVoltage += r(-0.05, 0.05);
  s.batteryVoltage = clamp(s.batteryVoltage, 11.5, 13.5);

  saveSensors(s);
  return s;
}

/* ─────────────────────────────────────────────
   REFUEL (restore fuel to 100)
───────────────────────────────────────────── */
function refuel() {
  const s = getSensors();
  if (!s) return;
  s.fuelLevel = 100;
  saveSensors(s);
}

/* ─────────────────────────────────────────────
   INFLATE TYRES (restore pressures)
───────────────────────────────────────────── */
function inflateTyres() {
  const s = getSensors();
  if (!s) return;
  s.tyrePressureFL = 32;
  s.tyrePressureFR = 32;
  s.tyrePressureRL = 31;
  s.tyrePressureRR = 31;
  saveSensors(s);
}

/* ─────────────────────────────────────────────
   DERIVED STATUS HELPERS
───────────────────────────────────────────── */
function getTempStatus(t) {
  if (t >= 105) return { label: 'CRITICAL', cls: 'status-critical', color: 'red' };
  if (t >= 95)  return { label: 'WARNING',  cls: 'status-warn',     color: 'orange' };
  return             { label: 'NORMAL',   cls: 'status-good',     color: 'green' };
}

function getFuelStatus(f) {
  if (f <= 10) return { label: 'CRITICAL', color: 'red' };
  if (f <= 20) return { label: 'LOW',      color: 'orange' };
  if (f <= 35) return { label: 'MODERATE', color: 'yellow' };
  return             { label: 'GOOD',     color: 'green' };
}

function getPressureStatus(p) {
  if (p < 24 || p > 34) return { label: 'DANGER',  color: 'red' };
  if (p < 27 || p > 33) return { label: 'LOW',     color: 'yellow' };
  return                       { label: 'OPTIMAL', color: 'green' };
}

function getBatteryVoltageStatus(v) {
  if (v < 11.8) return { label: 'CRITICAL', color: 'red' };
  if (v < 12.2) return { label: 'LOW',      color: 'orange' };
  if (v < 12.4) return { label: 'FAIR',     color: 'yellow' };
  return               { label: 'GOOD',     color: 'green' };
}
