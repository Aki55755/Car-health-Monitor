function generate(){

let temp=Math.floor(Math.random()*40)+70
let battery=Math.floor(Math.random()*50)+50
let fuel=Math.floor(Math.random()*100)
let tire=Math.floor(Math.random()*8)+28

document.getElementById("engineTemp").innerText=temp+" °C"
document.getElementById("battery").innerText=battery+" %"
document.getElementById("fuel").innerText=fuel+" %"
document.getElementById("tire").innerText=tire+" PSI"

let alerts=""

if(temp>100){
alerts+="🔥 Engine Overheating <br>"
}

if(fuel<20){
alerts+="⛽ Low Fuel <br>"
}

if(tire<30){
alerts+="🛞 Low Tire Pressure <br>"
}

document.getElementById("alerts").innerHTML=alerts

}

setInterval(generate,3000)